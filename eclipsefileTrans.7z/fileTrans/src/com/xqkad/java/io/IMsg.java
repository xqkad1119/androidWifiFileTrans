package com.xqkad.java.io;


public interface IMsg {
    public void sendMsg(int len);
}

