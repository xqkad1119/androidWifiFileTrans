package com.xqkad.java.net;

public class S {
	public final static int 
		CONNECT_ERROR = -1,
		HEART = 0,
		CONNECT_OK = 1,
		REQUEST_SEND_FILE = 2,
		RESULT_SEND_FILE_ERROR = 3,
		RESULT_SEND_FILE_OK = 4,
		SEND_FILE_FINISH = 5,
		FILE = 100;
}
